import React, { useState } from "react";
import { UserProvider, useUser } from "./contexts/UserContext";
import { DataProvider } from "./contexts/DataContext";
import { Auth } from "./components/Auth";
import { Header } from "./components/Header";
import { CurrentClass } from "./components/CurrentClass";
import { AssignmentCard } from "./components/AssignmentCard";
import { QuickAccess } from "./components/QuickAccess";
import { BottomNav } from "./components/BottomNav";
import { Timetable } from "./components/Timetable";
import { Resources } from "./components/Resources";
import { AIChat } from "./components/AIChat";
import { Profile } from "./components/Profile";
import { Notifications } from "./components/Notifications";
import { Search } from "./components/Search";
import { Projects } from "./components/Projects";
import { Files } from "./components/Files";
import { Ideas } from "./components/Ideas";
import { FacultyDashboard } from "./components/FacultyDashboard";
import { CreateAssignment } from "./components/CreateAssignment";
import { UploadResource } from "./components/UploadResource";
import { ManageClasses } from "./components/ManageClasses";
import { MonitorProjects } from "./components/MonitorProjects";

type ViewType = 'dashboard' | 'timetable' | 'resources' | 'profile' | 'notifications' | 'search' | 'projects' | 'files' | 'ideas' | 'create-assignment' | 'upload-resource' | 'manage-classes' | 'monitor-projects';

function AppContent() {
  const { user, login } = useUser();
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [showChat, setShowChat] = useState(false);

  // If no user is logged in, show auth screen
  if (!user) {
    return <Auth onLogin={login} />;
  }

  // Faculty-specific views
  if (user.role === 'faculty') {
    if (currentView === 'create-assignment') {
      return <CreateAssignment onBack={() => setCurrentView('dashboard')} />;
    }

    if (currentView === 'upload-resource') {
      return <UploadResource onBack={() => setCurrentView('dashboard')} />;
    }

    if (currentView === 'manage-classes') {
      return <ManageClasses onBack={() => setCurrentView('dashboard')} />;
    }

    if (currentView === 'monitor-projects') {
      return <MonitorProjects onBack={() => setCurrentView('dashboard')} />;
    }

    if (currentView === 'profile') {
      return (
        <div className="min-h-screen bg-gray-900">
          <Profile onBack={() => setCurrentView('dashboard')} />
          {showChat && <AIChat onClose={() => setShowChat(false)} />}
        </div>
      );
    }

    if (currentView === 'notifications') {
      return (
        <div className="min-h-screen bg-gray-900">
          <Notifications onBack={() => setCurrentView('dashboard')} />
          {showChat && <AIChat onClose={() => setShowChat(false)} />}
        </div>
      );
    }

    if (currentView === 'timetable') {
      return (
        <div className="min-h-screen bg-gray-900 pb-20">
          <Timetable onBack={() => setCurrentView('dashboard')} />
          <BottomNav 
            onChatClick={() => setShowChat(true)}
            onHomeClick={() => setCurrentView('dashboard')}
            onTimetableClick={() => setCurrentView('timetable')}
            onFilesClick={() => setCurrentView('files')}
            onIdeasClick={() => setCurrentView('ideas')}
            currentView={currentView}
          />
          {showChat && <AIChat onClose={() => setShowChat(false)} />}
        </div>
      );
    }

    if (currentView === 'resources') {
      return (
        <div className="min-h-screen bg-gray-900 pb-20">
          <Resources onBack={() => setCurrentView('dashboard')} />
          <BottomNav 
            onChatClick={() => setShowChat(true)}
            onHomeClick={() => setCurrentView('dashboard')}
            onTimetableClick={() => setCurrentView('timetable')}
            onFilesClick={() => setCurrentView('files')}
            onIdeasClick={() => setCurrentView('ideas')}
            currentView={currentView}
          />
          {showChat && <AIChat onClose={() => setShowChat(false)} />}
        </div>
      );
    }

    // Faculty Dashboard
    return (
      <div className="min-h-screen bg-gray-900 pb-20">
        <Header 
          userName={user.name}
          userAvatar={user.avatar}
          onSearchClick={() => setCurrentView('search')}
          onNotificationsClick={() => setCurrentView('notifications')}
          onProfileClick={() => setCurrentView('profile')}
        />
        
        <div className="px-5 mb-6">
          <FacultyDashboard onNavigate={setCurrentView} />
        </div>
        
        <BottomNav 
          onChatClick={() => setShowChat(true)}
          onHomeClick={() => setCurrentView('dashboard')}
          onTimetableClick={() => setCurrentView('timetable')}
          onFilesClick={() => setCurrentView('files')}
          onIdeasClick={() => setCurrentView('ideas')}
          currentView={currentView}
        />
        
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  // Student views (existing functionality)
  const assignments = [
    {
      title: "Neural Network Implementation",
      subject: "Deep Learning",
      dueDate: "Tomorrow",
      priority: "high" as const
    },
    {
      title: "Ethics in AI Essay", 
      subject: "AI Ethics",
      dueDate: "Friday",
      priority: "medium" as const
    },
    {
      title: "Database Design Project",
      subject: "Database Systems", 
      dueDate: "Next Week",
      priority: "low" as const
    }
  ];

  // Handle different views for students
  if (currentView === 'profile') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Profile onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'notifications') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Notifications onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'search') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Search onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'projects') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Projects onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'files') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Files onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'ideas') {
    return (
      <div className="min-h-screen bg-gray-900">
        <Ideas onBack={() => setCurrentView('dashboard')} />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'timetable') {
    return (
      <div className="min-h-screen bg-gray-900 pb-20">
        <Timetable onBack={() => setCurrentView('dashboard')} />
        <BottomNav 
          onChatClick={() => setShowChat(true)}
          onHomeClick={() => setCurrentView('dashboard')}
          onTimetableClick={() => setCurrentView('timetable')}
          onFilesClick={() => setCurrentView('files')}
          onIdeasClick={() => setCurrentView('ideas')}
          currentView={currentView}
        />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  if (currentView === 'resources') {
    return (
      <div className="min-h-screen bg-gray-900 pb-20">
        <Resources onBack={() => setCurrentView('dashboard')} />
        <BottomNav 
          onChatClick={() => setShowChat(true)}
          onHomeClick={() => setCurrentView('dashboard')}
          onTimetableClick={() => setCurrentView('timetable')}
          onFilesClick={() => setCurrentView('files')}
          onIdeasClick={() => setCurrentView('ideas')}
          currentView={currentView}
        />
        {showChat && <AIChat onClose={() => setShowChat(false)} />}
      </div>
    );
  }

  // Student Dashboard
  return (
    <div className="min-h-screen bg-gray-900 pb-20">
      <Header 
        userName={user.name}
        userAvatar={user.avatar}
        onSearchClick={() => setCurrentView('search')}
        onNotificationsClick={() => setCurrentView('notifications')}
        onProfileClick={() => setCurrentView('profile')}
      />
      
      <CurrentClass 
        className="Machine Learning Fundamentals"
        room="Room 101"
        instructor="Dr. Sarah Chen"
        timeRemaining="23 minutes remaining"
      />
      
      <div className="px-5 mb-6">
        <h2 className="text-white text-xl font-bold mb-4">Upcoming Assignments</h2>
        <div className="space-y-3">
          {assignments.map((assignment, index) => (
            <AssignmentCard key={index} {...assignment} />
          ))}
        </div>
      </div>
      
      <QuickAccess 
        onTimetableClick={() => setCurrentView('timetable')} 
        onResourcesClick={() => setCurrentView('resources')}
        onChatClick={() => setShowChat(true)}
        onProjectsClick={() => setCurrentView('projects')}
      />
      
      <BottomNav 
        onChatClick={() => setShowChat(true)}
        onHomeClick={() => setCurrentView('dashboard')}
        onTimetableClick={() => setCurrentView('timetable')}
        onFilesClick={() => setCurrentView('files')}
        onIdeasClick={() => setCurrentView('ideas')}
        currentView={currentView}
      />
      
      {showChat && <AIChat onClose={() => setShowChat(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <UserProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </UserProvider>
  );
}