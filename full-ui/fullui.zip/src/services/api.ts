/**
 * API Service Layer
 * Centralized API configuration and request handling
 * Industry-standard error handling and response management
 */

// API Configuration
const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:8000';

export interface ApiResponse<T = any> {
  data?: T;
  error?: string;
  status: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
  avatar?: string;
  studentClass?: string;
  facultySubjects?: string[];
  first_name?: string;
  last_name?: string;
}

export interface Class {
  id: string;
  name: string;
  code: string;
  instructor: string;
  room: string;
  start_time: string;
  end_time: string;
  day_of_week: string;
  course_id?: string;
  courses?: {
    name: string;
    code: string;
  };
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  due_date: string;
  course_id: string;
  created_by: string;
  courses?: {
    name: string;
    code: string;
  };
  priority?: 'high' | 'medium' | 'low';
}

// Generic API request handler with proper error handling
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const defaultOptions: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    console.log(`API Request: ${defaultOptions.method || 'GET'} ${url}`);

    const response = await fetch(url, defaultOptions);
    
    if (!response.ok) {
      console.error(`API Error: ${response.status} ${response.statusText}`);
      return {
        error: `API Error: ${response.status} ${response.statusText}`,
        status: response.status,
      };
    }

    const data = await response.json();
    console.log(`API Response:`, data);
    
    return {
      data,
      status: response.status,
    };
  } catch (error) {
    console.error('Network error:', error);
    return {
      error: `Network error: ${error instanceof Error ? error.message : 'Unknown error'}`,
      status: 0,
    };
  }
}

// Authentication API calls
export const authAPI = {
  async login(email: string, password: string, role: string): Promise<ApiResponse<{ user: User }>> {
    return apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, role }),
    });
  },

  async getCurrentUser(): Promise<ApiResponse<{ user: User }>> {
    return apiRequest('/api/auth/me');
  },

  async register(userData: {
    email: string;
    password: string;
    first_name: string;
    last_name: string;
    role: string;
    student_id?: string;
    department_id?: string;
    year_of_study?: string;
  }): Promise<ApiResponse<{ user: User }>> {
    return apiRequest('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },
};

// Classes/Timetable API calls
export const classesAPI = {
  async getAllClasses(): Promise<ApiResponse<{ classes: Class[] }>> {
    return apiRequest('/api/classes');
  },

  async getTodaysClasses(): Promise<ApiResponse<{ classes: Class[] }>> {
    return apiRequest('/api/classes/today');
  },

  async getWeeklyTimetable(): Promise<ApiResponse<{ weekly_classes: Class[] }>> {
    return apiRequest('/api/classes/week');
  },

  async getMonthlyClasses(): Promise<ApiResponse<{ monthly_classes: Class[] }>> {
    return apiRequest('/api/classes/month');
  },

  async getCurrentClass(): Promise<ApiResponse<{ current_class: Class }>> {
    return apiRequest('/api/classes/current');
  },

  async getNextClass(): Promise<ApiResponse<{ next_class: Class }>> {
    return apiRequest('/api/classes/next');
  },

  async getClassById(classId: string): Promise<ApiResponse<{ class: Class }>> {
    return apiRequest(`/api/classes/${classId}`);
  },
};

// Assignments API calls
export const assignmentsAPI = {
  async getAllAssignments(): Promise<ApiResponse<{ assignments: Assignment[] }>> {
    return apiRequest('/api/assignments');
  },

  async getUpcomingAssignments(): Promise<ApiResponse<{ assignments: Assignment[] }>> {
    return apiRequest('/api/assignments/upcoming');
  },

  async getOverdueAssignments(): Promise<ApiResponse<{ assignments: Assignment[] }>> {
    return apiRequest('/api/assignments/overdue');
  },
};

// Dashboard API calls
export const dashboardAPI = {
  async getDashboard(): Promise<ApiResponse<{
    current_session: any;
    recent_classes: Class[];
    recent_assignments: Assignment[];
  }>> {
    return apiRequest('/api/dashboard');
  },

  async getCurrentSession(): Promise<ApiResponse<{ session: any }>> {
    return apiRequest('/api/sessions/current');
  },
};

// Users API calls
export const usersAPI = {
  async getAllUsers(): Promise<ApiResponse<{ users: User[] }>> {
    return apiRequest('/api/users');
  },

  async getUserProfile(): Promise<ApiResponse<{ user: User }>> {
    return apiRequest('/api/users/me');
  },

  async getUserById(userId: string): Promise<ApiResponse<{ user: User }>> {
    return apiRequest(`/api/users/${userId}`);
  },

  async searchUsers(query?: string): Promise<ApiResponse<{ users: User[] }>> {
    const endpoint = query ? `/api/users/search?query=${encodeURIComponent(query)}` : '/api/users/search';
    return apiRequest(endpoint);
  },
};

// Health check
export const healthAPI = {
  async checkHealth(): Promise<ApiResponse<{ status: string; supabase: string; database: string }>> {
    return apiRequest('/health');
  },

  async getRoot(): Promise<ApiResponse<{ message: string; status: string }>> {
    return apiRequest('/');
  },
};

export default {
  auth: authAPI,
  classes: classesAPI,
  assignments: assignmentsAPI,
  dashboard: dashboardAPI,
  users: usersAPI,
  health: healthAPI,
};