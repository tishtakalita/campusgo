import React from "react";
import { Book, Calendar, ChevronRight, AlertTriangle, AlertCircle, CheckCircle } from "lucide-react";

interface AssignmentCardProps {
  title: string;
  subject: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
}

export function AssignmentCard({ title, subject, dueDate, priority }: AssignmentCardProps) {
  const getPriorityConfig = () => {
    switch (priority) {
      case 'high':
        return {
          colors: 'from-red-600 to-red-500',
          borderColor: 'border-red-600',
          icon: AlertTriangle,
          label: 'High Priority'
        };
      case 'medium':
        return {
          colors: 'from-orange-600 to-yellow-500',
          borderColor: 'border-orange-600',
          icon: AlertCircle,
          label: 'Medium Priority'
        };
      case 'low':
        return {
          colors: 'from-green-600 to-emerald-500',
          borderColor: 'border-green-600',
          icon: CheckCircle,
          label: 'Low Priority'
        };
      default:
        return {
          colors: 'from-gray-600 to-gray-500',
          borderColor: 'border-gray-600',
          icon: AlertCircle,
          label: 'Priority'
        };
    }
  };

  const config = getPriorityConfig();
  const IconComponent = config.icon;

  return (
    <button className="w-full text-left group">
      <div className="bg-gray-800 rounded-2xl border border-white/10 overflow-hidden shadow-lg hover:shadow-xl transition-all duration-200 group-hover:border-white/20 relative">
        <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${config.colors}`}></div>
        
        <div className="p-4">
          <div className="flex justify-between items-start mb-3 gap-3">
            <div className="flex-1">
              <h3 className="text-white font-semibold text-base leading-snug mb-2">{title}</h3>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-gray-700/50 flex items-center justify-center">
                  <Book size={11} className="text-gray-500" />
                </div>
                <span className="text-gray-400 text-sm font-medium">{subject}</span>
              </div>
            </div>
            
            <div className={`bg-gradient-to-r ${config.colors} px-2 py-1 rounded-xl flex items-center gap-1`}>
              <IconComponent size={10} className="text-white" />
              <span className="text-white text-xs font-semibold uppercase tracking-wide">{config.label}</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gray-700/50 flex items-center justify-center">
                <Calendar size={12} className="text-gray-500" />
              </div>
              <span className="text-gray-300 text-sm font-medium">Due {dueDate}</span>
            </div>
            
            <div className="w-8 h-8 rounded-full bg-gray-700/50 flex items-center justify-center group-hover:bg-gray-600/50 transition-colors">
              <ChevronRight size={14} className="text-gray-500" />
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}