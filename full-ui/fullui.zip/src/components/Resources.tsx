import React, { useState } from "react";
import { ArrowLeft, Search, Book, PlayCircle, FileText, Link, Filter } from "lucide-react";
import { useData } from "../contexts/DataContext";
import { useUser } from "../contexts/UserContext";

interface ResourcesProps {
  onBack: () => void;
}

export function Resources({ onBack }: ResourcesProps) {
  const { resources, classes } = useData();
  const { user } = useUser();
  const [activeFilter, setActiveFilter] = useState<'all' | 'notes' | 'video' | 'link' | 'document'>('all');
  const [searchQuery, setSearchQuery] = useState("");

  // Filter resources based on user role
  const userResources = user?.role === 'faculty' 
    ? resources.filter(resource => {
        const resourceClass = classes.find(cls => cls.id === resource.classId);
        return resourceClass && user.facultySubjects?.includes(resourceClass.name);
      })
    : resources; // Students see all resources

  const getIcon = (type: string) => {
    switch (type) {
      case "notes": return FileText;
      case "video": return PlayCircle;
      case "link": return Link;
      case "document": return Book;
      default: return Book;
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case "notes": return "text-blue-500";
      case "video": return "text-red-500";
      case "link": return "text-green-500";
      case "document": return "text-purple-500";
      default: return "text-gray-500";
    }
  };

  const getClassName = (classId: string) => {
    return classes.find(cls => cls.id === classId)?.name || 'Unknown Class';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return date.toLocaleDateString();
  };

  const filteredResources = userResources.filter(resource => 
    (activeFilter === 'all' || resource.type === activeFilter) &&
    (searchQuery === '' || 
     resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
     resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
     resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    )
  );

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="px-5 py-4 border-b border-white/10">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 mb-4"
        >
          <ArrowLeft size={20} className="text-white" />
          <h1 className="text-white text-xl font-bold">Resources</h1>
        </button>
        
        <div className="relative mb-4">
          <Search size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search resources..."
            className="w-full bg-gray-800 border border-white/10 rounded-2xl pl-12 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto">
          {[
            { key: 'all', label: 'All' },
            { key: 'notes', label: 'Notes' },
            { key: 'video', label: 'Videos' },
            { key: 'link', label: 'Links' },
            { key: 'document', label: 'Documents' }
          ].map((filter) => (
            <button
              key={filter.key}
              onClick={() => setActiveFilter(filter.key as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeFilter === filter.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-5 space-y-3">
        {filteredResources.length === 0 ? (
          <div className="text-center py-12">
            <Book className="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <h3 className="text-white font-semibold mb-2">No Resources Found</h3>
            <p className="text-gray-400 text-sm">
              {searchQuery ? 'Try adjusting your search terms' : 'No resources available yet'}
            </p>
          </div>
        ) : (
          filteredResources.map((resource) => {
            const IconComponent = getIcon(resource.type);
            const iconColor = getIconColor(resource.type);
            
            return (
              <div key={resource.id} className="p-4 bg-gray-800 rounded-2xl border border-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                    <IconComponent size={18} className={iconColor} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-1">{resource.title}</h3>
                    <p className="text-gray-400 text-sm mb-2">{getClassName(resource.classId)}</p>
                    <p className="text-gray-300 text-sm mb-2">{resource.description}</p>
                    <div className="flex items-center gap-3 text-xs text-gray-500 mb-2">
                      <span>By {resource.uploadedBy}</span>
                      <span>•</span>
                      <span>{formatDate(resource.uploadDate)}</span>
                    </div>
                    {resource.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {resource.tags.map((tag, index) => (
                          <span key={index} className="px-2 py-1 bg-blue-600/20 text-blue-400 text-xs rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}