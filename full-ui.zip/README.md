
  # Student Platform UI Design

  This is a code bundle for Student Platform UI Design. The original project is available at https://www.figma.com/design/W3Gl0NljwSRHQGCuZDFeU8/Student-Platform-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  