import React, { useState } from 'react';
import { useUser } from '../contexts/UserContext';
import { useData } from '../contexts/DataContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ArrowLeft, Upload, FileText, Video, Link, File } from 'lucide-react';

interface UploadResourceProps {
  onBack: () => void;
}

export const UploadResource: React.FC<UploadResourceProps> = ({ onBack }) => {
  const { user } = useUser();
  const { classes, addResource } = useData();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'notes' | 'video' | 'link' | 'document'>('notes');
  const [url, setUrl] = useState('');
  const [classId, setClassId] = useState('');
  const [tags, setTags] = useState('');

  // Filter classes for faculty
  const facultyClasses = classes.filter(cls => 
    user?.facultySubjects?.includes(cls.name)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !description || !url || !classId) {
      return;
    }

    addResource({
      title,
      description,
      type,
      url,
      classId,
      uploadedBy: user?.name || 'Faculty',
      uploadDate: new Date().toISOString().split('T')[0],
      tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag)
    });

    // Reset form
    setTitle('');
    setDescription('');
    setType('notes');
    setUrl('');
    setClassId('');
    setTags('');

    // Go back to dashboard
    onBack();
  };

  const getTypeIcon = (resourceType: string) => {
    switch (resourceType) {
      case 'notes':
        return FileText;
      case 'video':
        return Video;
      case 'link':
        return Link;
      case 'document':
        return File;
      default:
        return FileText;
    }
  };

  const TypeIcon = getTypeIcon(type);

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="text-white hover:bg-gray-800 mr-3"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-bold text-white">Upload Resource</h1>
        </div>

        <Card className="bg-gray-800 border-gray-700">
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Resource Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="text-white">Resource Title</Label>
              <Input
                id="title"
                type="text"
                placeholder="Enter resource title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                required
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description" className="text-white">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe the resource and its purpose"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 min-h-[80px]"
                required
              />
            </div>

            {/* Resource Type */}
            <div className="space-y-2">
              <Label htmlFor="type" className="text-white">Resource Type</Label>
              <Select value={type} onValueChange={(value: 'notes' | 'video' | 'link' | 'document') => setType(value)}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <div className="flex items-center">
                    <TypeIcon className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="notes">
                    <div className="flex items-center">
                      <FileText className="w-4 h-4 mr-2" />
                      Notes
                    </div>
                  </SelectItem>
                  <SelectItem value="video">
                    <div className="flex items-center">
                      <Video className="w-4 h-4 mr-2" />
                      Video
                    </div>
                  </SelectItem>
                  <SelectItem value="link">
                    <div className="flex items-center">
                      <Link className="w-4 h-4 mr-2" />
                      Link
                    </div>
                  </SelectItem>
                  <SelectItem value="document">
                    <div className="flex items-center">
                      <File className="w-4 h-4 mr-2" />
                      Document
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* URL */}
            <div className="space-y-2">
              <Label htmlFor="url" className="text-white">
                {type === 'link' ? 'URL' : type === 'video' ? 'Video URL' : 'File Path/URL'}
              </Label>
              <Input
                id="url"
                type="url"
                placeholder={
                  type === 'link' ? 'https://example.com' :
                  type === 'video' ? 'https://youtube.com/watch?v=...' :
                  '/path/to/file.pdf'
                }
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                required
              />
            </div>

            {/* Class Selection */}
            <div className="space-y-2">
              <Label htmlFor="class" className="text-white">Class</Label>
              <Select value={classId} onValueChange={setClassId} required>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue placeholder="Select a class" />
                </SelectTrigger>
                <SelectContent>
                  {facultyClasses.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name} ({cls.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <Label htmlFor="tags" className="text-white">Tags (comma-separated)</Label>
              <Input
                id="tags"
                type="text"
                placeholder="e.g., neural networks, basics, fundamentals"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              disabled={!title || !description || !url || !classId}
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload Resource
            </Button>
          </form>
        </Card>

        {/* Tips */}
        <Card className="bg-gray-800 border-gray-700 mt-4">
          <div className="p-4">
            <h3 className="text-white font-semibold mb-2">Upload Guidelines</h3>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Ensure content is relevant to the selected class</li>
              <li>• Use descriptive titles and tags for easy searching</li>
              <li>• Verify all links work before uploading</li>
              <li>• Consider file size and accessibility</li>
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
};