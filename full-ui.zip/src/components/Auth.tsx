import React, { useState } from 'react';
import { User, UserRole } from '../contexts/UserContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { GraduationCap, Users, Shield } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('student');

  const handleLogin = () => {
    if (!name || !email) return;

    const mockUsers = {
      student: {
        id: 'student1',
        name: name || 'Alex Johnson',
        email: email || 'alex.johnson@university.edu',
        role: 'student' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1729824186570-4d4aede00043?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBzdHVkZW50JTIwYXZhdGFyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4MDMwNzA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
        studentClass: 'Computer Science - Year 3'
      },
      faculty: {
        id: 'faculty1',
        name: name || 'Dr. Sarah Chen',
        email: email || 'sarah.chen@university.edu',
        role: 'faculty' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmYWN1bHR5JTIwYXZhdGFyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4MDMwNzA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
        facultySubjects: ['Machine Learning Fundamentals', 'Deep Learning', 'AI Ethics']
      },
      admin: {
        id: 'admin1',
        name: name || 'Dr. Michael Admin',
        email: email || 'admin@university.edu',
        role: 'admin' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhZG1pbiUyMGF2YXRhciUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODAzMDcwN3ww&ixlib=rb-4.1.0&q=80&w=1080'
      }
    };

    const userData = { ...mockUsers[role], name, email };
    onLogin(userData);
  };

  const quickLogin = (userRole: UserRole) => {
    const mockUsers = {
      student: {
        id: 'student1',
        name: 'Alex Johnson',
        email: 'alex.johnson@university.edu',
        role: 'student' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1729824186570-4d4aede00043?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBzdHVkZW50JTIwYXZhdGFyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4MDMwNzA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
        studentClass: 'Computer Science - Year 3'
      },
      faculty: {
        id: 'faculty1',
        name: 'Dr. Sarah Chen',
        email: 'sarah.chen@university.edu',
        role: 'faculty' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmYWN1bHR5JTIwYXZhdGFyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4MDMwNzA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
        facultySubjects: ['Machine Learning Fundamentals', 'Deep Learning', 'AI Ethics']
      },
      admin: {
        id: 'admin1',
        name: 'Dr. Michael Admin',
        email: 'admin@university.edu',
        role: 'admin' as UserRole,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhZG1pbiUyMGF2YXRhciUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODAzMDcwN3ww&ixlib=rb-4.1.0&q=80&w=1080'
      }
    };

    onLogin(mockUsers[userRole]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-4">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">AI Student Platform</h1>
          <p className="text-gray-300">Choose your role to continue</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-white">Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-white">Role</Label>
              <Select value={role} onValueChange={(value: UserRole) => setRole(value)}>
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="faculty">Faculty</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
              disabled={!name || !email}
            >
              Login
            </Button>
          </div>
        </Card>

        <div className="space-y-3">
          <p className="text-center text-gray-300 text-sm">Quick Login (Demo)</p>
          <div className="grid grid-cols-3 gap-2">
            <Button
              onClick={() => quickLogin('student')}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 p-3 h-auto flex-col space-y-1"
            >
              <GraduationCap className="w-5 h-5" />
              <span className="text-xs">Student</span>
            </Button>
            <Button
              onClick={() => quickLogin('faculty')}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 p-3 h-auto flex-col space-y-1"
            >
              <Users className="w-5 h-5" />
              <span className="text-xs">Faculty</span>
            </Button>
            <Button
              onClick={() => quickLogin('admin')}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 p-3 h-auto flex-col space-y-1"
            >
              <Shield className="w-5 h-5" />
              <span className="text-xs">Admin</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};