import React, { useState } from "react";
import { ArrowLeft, Calendar, Clock, MapPin, Users } from "lucide-react";
import { useData } from "../contexts/DataContext";
import { useUser } from "../contexts/UserContext";

interface TimetableProps {
  onBack: () => void;
}

export function Timetable({ onBack }: TimetableProps) {
  const { classes } = useData();
  const { user } = useUser();
  const [activeView, setActiveView] = useState<'day' | 'week' | 'month'>('day');

  // Filter classes based on user role
  const userClasses = user?.role === 'faculty' 
    ? classes.filter(cls => user.facultySubjects?.includes(cls.name))
    : classes; // Students see all classes

  // Get today's day name
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  
  // Get today's classes
  const todayClasses = userClasses.filter(cls =>
    cls.schedule.some(schedule => schedule.day === today)
  ).map(cls => {
    const todaySchedule = cls.schedule.find(schedule => schedule.day === today)!;
    
    // Check if class is currently ongoing
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    const isCurrentClass = currentTime >= todaySchedule.startTime && currentTime <= todaySchedule.endTime;
    
    return {
      ...cls,
      schedule: todaySchedule,
      status: isCurrentClass ? 'current' : 'upcoming'
    };
  }).sort((a, b) => a.schedule.startTime.localeCompare(b.schedule.startTime));

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getWeekView = () => {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const weekSchedule: { [key: string]: any[] } = {};
    
    days.forEach(day => {
      weekSchedule[day] = userClasses.filter(cls =>
        cls.schedule.some(schedule => schedule.day === day)
      ).flatMap(cls => 
        cls.schedule
          .filter(schedule => schedule.day === day)
          .map(schedule => ({ ...cls, schedule }))
      ).sort((a, b) => a.schedule.startTime.localeCompare(b.schedule.startTime));
    });
    
    return weekSchedule;
  };

  const weekSchedule = getWeekView();

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="px-5 py-4 border-b border-white/10">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 mb-4"
        >
          <ArrowLeft size={20} className="text-white" />
          <h1 className="text-white text-xl font-bold">Timetable</h1>
        </button>
        
        <div className="flex bg-gray-800 rounded-2xl p-1">
          {(['day', 'week', 'month'] as const).map((view) => (
            <button
              key={view}
              onClick={() => setActiveView(view)}
              className={`flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors ${
                activeView === view
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {view.charAt(0).toUpperCase() + view.slice(1)}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-5">
        {activeView === 'day' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <Calendar size={20} className="text-gray-400" />
              <h2 className="text-white text-lg font-semibold">
                Today, {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
              </h2>
            </div>
            
            <div className="space-y-4">
              {todayClasses.length === 0 ? (
                <div className="text-center py-12">
                  <Calendar className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-white font-semibold mb-2">No Classes Today</h3>
                  <p className="text-gray-400 text-sm">Enjoy your free day!</p>
                </div>
              ) : (
                todayClasses.map((classItem) => (
                  <div 
                    key={classItem.id} 
                    className={`p-4 rounded-2xl border ${
                      classItem.status === 'current'
                        ? 'bg-blue-600/20 border-blue-500'
                        : 'bg-gray-800 border-white/10'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-white font-semibold text-lg mb-1">{classItem.name}</h3>
                        <p className="text-gray-400 text-sm">{classItem.instructor}</p>
                        <p className="text-gray-500 text-xs">{classItem.code}</p>
                      </div>
                      {classItem.status === 'current' && (
                        <span className="px-2 py-1 bg-blue-600 text-white text-xs font-semibold rounded-full">
                          LIVE
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock size={14} className="text-gray-400" />
                        <span className="text-gray-300">
                          {formatTime(classItem.schedule.startTime)} - {formatTime(classItem.schedule.endTime)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin size={14} className="text-gray-400" />
                        <span className="text-gray-300">{classItem.room}</span>
                      </div>
                      {user?.role === 'faculty' && (
                        <div className="flex items-center gap-2">
                          <Users size={14} className="text-gray-400" />
                          <span className="text-gray-300">{classItem.students.length}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </>
        )}

        {activeView === 'week' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <Calendar size={20} className="text-gray-400" />
              <h2 className="text-white text-lg font-semibold">This Week</h2>
            </div>
            
            <div className="space-y-6">
              {Object.entries(weekSchedule).map(([day, dayClasses]) => (
                <div key={day}>
                  <h3 className="text-white font-semibold mb-3">{day}</h3>
                  {dayClasses.length === 0 ? (
                    <p className="text-gray-500 text-sm mb-4">No classes</p>
                  ) : (
                    <div className="space-y-3 mb-4">
                      {dayClasses.map((classItem, index) => (
                        <div key={`${classItem.id}-${index}`} className="p-3 bg-gray-800 rounded-xl border border-white/10">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-white font-medium">{classItem.name}</h4>
                              <p className="text-gray-400 text-sm">{classItem.instructor}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-gray-300 text-sm">
                                {formatTime(classItem.schedule.startTime)} - {formatTime(classItem.schedule.endTime)}
                              </p>
                              <p className="text-gray-500 text-xs">{classItem.room}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </>
        )}

        {activeView === 'month' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <Calendar size={20} className="text-gray-400" />
              <h2 className="text-white text-lg font-semibold">
                {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h2>
            </div>
            
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-white font-semibold mb-2">Month View</h3>
              <p className="text-gray-400 text-sm">Calendar view coming soon</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}